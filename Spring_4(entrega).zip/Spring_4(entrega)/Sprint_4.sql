CREATE DATABASE IF NOT EXISTS sprint_4; -- creamos base de tatos
USE sprint_4;

-- creamos tablas --

CREATE TABLE IF NOT EXISTS transaction (

id VARCHAR (255) PRIMARY KEY ,
card_id VARCHAR (20) ,
business_id VARCHAR (255) ,
timestamp TIMESTAMP ,
amount DECIMAL (10,2) ,
declined BOOLEAN ,
product_ids VARCHAR (20) ,
user_id VARCHAR (255) ,
lat FLOAT ,
longitude FLOAT );



CREATE TABLE IF NOT EXISTS users (
    id VARCHAR (255)  PRIMARY KEY ,
    name VARCHAR(50) ,
    surname VARCHAR(50) ,
    phone VARCHAR(25),
    email VARCHAR(100) ,
   birth_day VARCHAR (20),
    country VARCHAR(50),
    city VARCHAR(50),
    postal_code VARCHAR(20),
    address VARCHAR(150)
);

CREATE TABLE IF NOT EXISTS credit_cards (
    id VARCHAR (255)  PRIMARY KEY ,
    user_id VARCHAR(50) ,
    iban VARCHAR(50) ,
    pan VARCHAR(25),
    pin VARCHAR(100) ,
   cvv VARCHAR (20),
    track1 VARCHAR(50),
    track2 VARCHAR(50),
    expiring_date VARCHAR(20)
);
CREATE TABLE IF NOT EXISTS companies (
    company_id VARCHAR (255)  PRIMARY KEY ,
    company_name VARCHAR(50) ,
    phone VARCHAR(50) ,
    email VARCHAR(25),
    country VARCHAR(100) ,
   website VARCHAR (20)
   );
CREATE TABLE IF NOT EXISTS products (
    id VARCHAR (255)  PRIMARY KEY ,
    product_name VARCHAR(50) ,
    price VARCHAR(50) ,
    colour VARCHAR(25),
    weight VARCHAR(100) ,
    warehouse_id VARCHAR (20)
   );

 -- pasamos datos a nuestras tablas creadas (hubo un liooooo)--
LOAD DATA INFILE 'C:/xampp/tmp/credit_cards.csv'
INTO TABLE credit_cards
FIELDS terminated by ','
enclosed by '"'
ignore 1 rows
;
-- creamos relaciones (FK) --
ALTER TABLE transaction
ADD CONSTRAINT card_id
FOREIGN KEY (card_id) REFERENCES card(id);

ALTER TABLE transaction
ADD CONSTRAINT fk_user_id
FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE transaction
ADD CONSTRAINT fk_card_id
FOREIGN KEY (card_id) REFERENCES credit_cards(id);

ALTER TABLE transaction
ADD constraint fk_business_id
foreign key (business_id) references companies(company_id);

  ALTER table transaction
  add constraint fk_product_ids
  foreign key (product_ids) references products(id);
  
  -- SELECT*FROM products;
-- SHOW TABLES;
-- drop table status_credit_cards;
-- SET GLOBAL local_infile = 1;
-- SHOW  variables like "local_infile";
-- SHOW  variables like "secure_file_priv";



-- NIVEL-1-1-

SELECT u.id, u.name, u.surname
FROM users u
WHERE u.id IN (
    SELECT t.user_id
    FROM transactions t
    GROUP BY t.user_id
    HAVING COUNT(t.id) > 80
)
limit 0,100;


-- NIVEL-1-2--  
 
SELECT cc.iban,
       AVG(t.amount) AS media_amount
FROM transactions t
JOIN credit_cards cc ON t.card_id = cc.id
JOIN companies c ON t.business_id = c.company_id
WHERE c.company_name = 'Donec Ltd'
GROUP BY cc.iban;

-- NIVEL-2-- (creamos una tabla que se debuelba valor si la tarjeta esta activa o no )
create table if not exists status_credit_cards (
credit_card_id varchar(255)primary key,
status_card enum ('active','inactive'),
FOREIGN KEY (credit_card_id) REFERENCES credit_cards(id)
);
INSERT INTO status_credit_cards (credit_card_id, status_card)
SELECT card_id,
       CASE 
           WHEN SUM(declined) = 3 THEN 'inactive'
           ELSE 'active'
       END AS status
FROM (
    SELECT 
        t.card_id,
        t.declined,
        ROW_NUMBER() OVER (PARTITION BY t.card_id ORDER BY t.timestamp DESC) AS rn
    FROM transactions t
) AS sub
WHERE rn <= 3
GROUP BY card_id;
select count(*) AS card_activas
from status_credit_cards
where status_card = 'active';


-- NIVEL-3--

-- creamos una sub tabla para conectar tablas transactiones y products, para tener relaciones 1:N.
create table transactions_products (
transaction_id varchar (255) primary key,
product_id varchar (255) ,
cantidad varchar (255),
foreign key (transaction_id) references transactions(id),
foreign key (product_id) references products(id) 
);
-- número de veces que se ha vendido cada producto.
SELECT 
    p.id,
    p.product_name,
    COUNT(tp.transaction_id) AS times_sold
FROM products p
LEFT JOIN transactions_products tp 
    ON p.id = tp.product_id
GROUP BY p.id, p.product_name
ORDER BY times_sold desc;

